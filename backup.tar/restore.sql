--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0 (Ubuntu 16.0-1.pgdg22.04+1)
-- Dumped by pg_dump version 16.0 (Ubuntu 16.0-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE currency_storage;
--
-- Name: currency_storage; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE currency_storage WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE currency_storage OWNER TO postgres;

\connect currency_storage

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: currency_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.currency_values (
    id integer NOT NULL,
    currency_value numeric(8,4) NOT NULL,
    update_datetime_id integer NOT NULL,
    info_num_code integer NOT NULL
);


ALTER TABLE public.currency_values OWNER TO postgres;

--
-- Name: currency_values_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.currency_values_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.currency_values_id_seq OWNER TO postgres;

--
-- Name: currency_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.currency_values_id_seq OWNED BY public.currency_values.id;


--
-- Name: info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.info (
    num_code integer NOT NULL,
    char_code character varying(3) NOT NULL,
    multiplier_id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.info OWNER TO postgres;

--
-- Name: multipliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.multipliers (
    id integer NOT NULL,
    multiplier integer NOT NULL
);


ALTER TABLE public.multipliers OWNER TO postgres;

--
-- Name: update_datetimes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.update_datetimes (
    id integer NOT NULL,
    update_datetime timestamp with time zone NOT NULL
);


ALTER TABLE public.update_datetimes OWNER TO postgres;

--
-- Name: update_datetimes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.update_datetimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.update_datetimes_id_seq OWNER TO postgres;

--
-- Name: update_datetimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.update_datetimes_id_seq OWNED BY public.update_datetimes.id;


--
-- Name: currency_values id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currency_values ALTER COLUMN id SET DEFAULT nextval('public.currency_values_id_seq'::regclass);


--
-- Name: update_datetimes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.update_datetimes ALTER COLUMN id SET DEFAULT nextval('public.update_datetimes_id_seq'::regclass);


--
-- Data for Name: currency_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.currency_values (id, currency_value, update_datetime_id, info_num_code) FROM stdin;
\.
COPY public.currency_values (id, currency_value, update_datetime_id, info_num_code) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.info (num_code, char_code, multiplier_id, name) FROM stdin;
\.
COPY public.info (num_code, char_code, multiplier_id, name) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: multipliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.multipliers (id, multiplier) FROM stdin;
\.
COPY public.multipliers (id, multiplier) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: update_datetimes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.update_datetimes (id, update_datetime) FROM stdin;
\.
COPY public.update_datetimes (id, update_datetime) FROM '$$PATH$$/3390.dat';

--
-- Name: currency_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.currency_values_id_seq', 301, true);


--
-- Name: update_datetimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.update_datetimes_id_seq', 7, true);


--
-- Name: currency_values pk_currency_values; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currency_values
    ADD CONSTRAINT pk_currency_values PRIMARY KEY (id);


--
-- Name: info pk_info; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.info
    ADD CONSTRAINT pk_info PRIMARY KEY (num_code);


--
-- Name: multipliers pk_multipliers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.multipliers
    ADD CONSTRAINT pk_multipliers PRIMARY KEY (id);


--
-- Name: update_datetimes pk_update_datetimes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.update_datetimes
    ADD CONSTRAINT pk_update_datetimes PRIMARY KEY (id);


--
-- Name: currency_values fk_currency_values_info; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currency_values
    ADD CONSTRAINT fk_currency_values_info FOREIGN KEY (info_num_code) REFERENCES public.info(num_code) ON DELETE CASCADE;


--
-- Name: currency_values fk_currency_values_update_datetimes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currency_values
    ADD CONSTRAINT fk_currency_values_update_datetimes FOREIGN KEY (update_datetime_id) REFERENCES public.update_datetimes(id) ON DELETE CASCADE;


--
-- Name: info fk_info_multipliers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.info
    ADD CONSTRAINT fk_info_multipliers FOREIGN KEY (multiplier_id) REFERENCES public.multipliers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

